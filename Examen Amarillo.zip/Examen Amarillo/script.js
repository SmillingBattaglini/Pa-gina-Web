function displayAlert(elemento_car){

    alert("Your car is empty");
}

function dismissCookie() {
    var cookie_element = document.querySelector('.footer');
    cookie_element.remove();
}
